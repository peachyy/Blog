title: 《游戏开发中的数学和物理》读书笔记
date: 2015-12-23 11:11:06
categories: [读书笔记]
tags: [游戏开发,数学,物理]
---
&emsp;&emsp;本文为博主阅读《游戏开发中的数学和物理》一书后整理的读书笔记，这本书选取了游戏开发中最常用的数学和物理学知识，内容涉及了物体的运动、卷动、碰撞检测、光线的制作、画面切换等内容，想阅读这本书的朋友可以通过本文了解些简略的内容。

<!--more-->
#物体的运动
&emsp;&emsp;从数学意义上来说，因为三角函数具有周期性的特点，因此在数学中无论一个角度多大都不会有问题。可是在角的弧度制在计算机内部是以浮点数来表示的，因此使用浮点数计会存在精度丢失的问题。如非特殊需要，在计算机中使用三角函数时应注意尽可能地控制角度的取值范围在0到2π间。
&emsp;&emsp;为了获得0到n间的随机数，可以使用以下算法，其中RAND_MAX是在C语言头文件中定义的一个常量表示rand函数能够返回的最大值：
```
rand() * n / (float)RAND_MAX
```
因此rand()  / (float)RAND_MAX可以返回0到1间的随机数，由此可证明以上算法可以返回0到n间的随机数。
&emsp;&emsp;通过下面的求余同样可以返回0到n间的随机数，可是需要注意求余得到的结果必然为整数，因此可以通过这个方法返回0到n间的整型随机数：
```
rand() % (n+1)
```
&emsp;&emsp;计算a到b间的随机数可以使用以下公式来计算：
```
rand() * (b-a) / (float)RAND_MAX + a
```
&emsp;&emsp;自然界中的随机事件通常满足正态分布，计算机中使用的随机数是伪随机数并非是严格意义上的均匀分布。Box-Muller算法是一种根据均匀分布的随机数来产生正态分布的随机数的算法，假设a、b是两个服从均匀分布并且取值范围为从0到1的随机数，则我们可以童工下面的公式来获得两个满足正态分布（均数为0，标准差为1）的随机数Z1和Z2:
```
Z1 = sqrt(-2ln(a)) * cos(2πb)
Z2 = sqrt(-2ln(a)) * sin(2πb)
```
&emsp;&emsp;物体的圆周运动可以基于广义三角函数定义和基于向心力两种方法来实现，基于向心力实现的的圆周运动相对基于三角函数实现的圆周运动在效率上更好。
&emsp;&emsp;欧拉法是通过逐步计算来求得微分方程的近似解。

#卷动
&emsp;&emsp;一重卷动，即实现单张背景图片的卷动。假设画面宽度为VIEW_WIDTH、镜头的移动速度为CAMERA_VEL，则一重卷动的代码实现如下：
```
//镜头初始位置
float fCamera_x = 0;
//背景初始位置
float fBack_x = 0;

void init()
{
    fCamera_x = VIEW_WIDTH / 2.0f;
    fBack_x = VIEW_WIDTH / 2.0f - fCamera_x;
}

void Update()
{
    if(GetAsyncKeyState(VK_LEFT))
    {
        fCamera_x -= CAMERA_VEL;
        if(fCamera_x < VIEW_WIDTH / 2.0f)
           fCamera_x < VIEW_WIDTH / 2.0f; 
    }

    if(GetAsyncKeyState(VK_RIGHT))
    {
        fCamera_x += CAMERA_VEL;
        if(fCamera_x > (float)(PICTURE_WIDTH - VIEW_WIDTH / 2.0f))
           fCamera_x = (float)(PICTURE_WIDTH - VIEW_WIDTH / 2.0f) 
    }

    fBack_x = VIEW_WIDTH / 2.0f - fCamera_x;
}
```

&emsp;&emsp;多重卷动即多张背景图片卷动。在设置卷动速度时应注意到这样一个点，即图片宽度与图片卷动速度成正比。一个结论性的观点是在卷动的时候以第一张背景图片为基准进行卷动。代码实现如下：
```
fBack1_x = VIEW_WIDTH / 2.0f - fCamera_x;
fBack2_x = (float)(PICTURE2_WIDTH - VIEW_WIDTH) / (PICTURE1_WIDTH - VIEW_WIDTH)*  fBack1_x
fBack3_x = (float)(PICTURE3_WIDTH - VIEW_WIDTH) / (PICTURE1_WIDTH - VIEW_WIDTH)*  fBack1_x
```
&emsp;&emsp;角色运动和背景卷动的联动需要考虑画面两端相机无法到达的区域范围，即当角色到达画面边缘的时候，此时相机的视野已超出画面范围，应该停止镜头和角色间的联动作用。
&emsp;&emsp;由地块组成的可卷动的大地图本质上是根据视野的范围来确定大地图中的地图范围然后进行绘制的。处理大地图卷动时首先需要计算视野范围内地图块左上角第一个元素的坐标，然后根据视野范围计算出需要绘制地块的数目，由此可以确定视野范围内绘制的地图。为了确保绘制范围是整数且在卷动的时候不会由空白，实际绘制的地块数目应该在计算结果的基础上增加2。乘法运算可以通过AND运算符来代替，除法运算可以通过移位运算来代替。

&emsp;&emsp;在处理画面波纹式扭曲问题时可以考虑使用正弦波函数来实现，简单的正弦波函数定义如下：
```
y=A * sin(2π * x / lumber)
```
更为复杂地可以定义一个随时间周期性变化的正弦波函数：
```
y=A * sin(2π * (t/T - x/lumber))
```






